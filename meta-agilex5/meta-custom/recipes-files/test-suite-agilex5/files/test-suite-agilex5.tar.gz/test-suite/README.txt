emb-test-suite test-suite package

Platform   : agilex5
Build type : release
Built UTC  : 2026-04-13T06:02:02Z

Quick start:
  ./test-suite list
  ./test-suite info ethernet ping-test
  ./test-suite doctor
  ./test-suite run ethernet ping-test -- 192.168.9.100

Package layout:
  test-suite           Main runner
  tests/<category>/    Test shell scripts
  manifest.tsv         Packaged test metadata
  metadata.env         Package metadata
  logs/                Runtime logs
