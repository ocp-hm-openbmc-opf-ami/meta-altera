#!/usr/bin/env bash
# iperf3 throughput test – shell port for ETH/Config1/iperf3_test
set -euo pipefail

if [ "${1:-}" = "--desc" ]; then
  echo "Run Iperf3 test in client or server mode between two DUTs."
  exit 0
fi

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  cat <<'EOF'
Usage:
  test_steps.sh server
  test_steps.sh <server-ip>

Examples:
  test_steps.sh server
  test_steps.sh 192.168.9.100
  IPERF_SERVER_IP=192.168.9.100 test_steps.sh
EOF
  exit 0
fi

: "${NET_IFACE:=eth0}"
: "${IPERF_TIME_SEC:=10}"
: "${TARGET:=BOARD}"

log()  { echo "[iperf3-test] $*"; }
fail() { echo "[iperf3-test] FAIL: $*" >&2; exit 1; }

MODE="client"
if [ "${1:-}" = "server" ] || [ "${1:-}" = "--server" ] || [ "${1:-}" = "-s" ]; then
    MODE="server"
    shift || true
fi

if ! command -v iperf3 >/dev/null 2>&1; then
    fail "iperf3 not found in PATH – please install iperf3 on this system"
fi

log "Dumping IPv4 configuration for $NET_IFACE"
ip -4 addr show "$NET_IFACE" || fail "Interface $NET_IFACE not found"

run_live_with_log() {
    local logfile="$1"; shift
    local cmd=( "$@" )
    if command -v stdbuf >/dev/null 2>&1; then
        cmd=( stdbuf -oL -eL "${cmd[@]}" )
    fi
    if ! "${cmd[@]}" 2>&1 | tee "$logfile"; then
        return 1
    fi
    return 0
}

if [ "$MODE" = "server" ]; then
    log "Running in SERVER mode"
    TMP_OUT="$(mktemp /tmp/iperf3_server.XXXXXX)"
    log "Starting iperf3 server (single-connection, then exit)"
    echo "---------- iperf3 output begin ----------"
    if ! run_live_with_log "$TMP_OUT" iperf3 -s -1; then
        echo "---------- iperf3 output end   ----------"
        echo "Log file: $TMP_OUT"
        fail "iperf3 server exited with error (see output above)"
    fi
    echo "---------- iperf3 output end   ----------"
    if ! grep -q "receiver" "$TMP_OUT"; then
        rm -f "$TMP_OUT"
        fail "Did not find 'receiver' summary line in iperf3 server output – treating as failure"
    fi
    rm -f "$TMP_OUT"
    log "iperf3 SERVER test PASSED (see above for measured bandwidth)"
    exit 0
fi

log "Running in CLIENT mode"
SERVER_IP="${1:-}"
: "${IPERF_SERVER_IP:=}"
if [ -z "$SERVER_IP" ] && [ -n "$IPERF_SERVER_IP" ]; then
    SERVER_IP="$IPERF_SERVER_IP"
fi

if [ -z "$SERVER_IP" ]; then
    fail "No iperf3 server IP provided. Use:
  test_steps.sh <server-ip>
or set IPERF_SERVER_IP, or run in server mode:
  test_steps.sh server"
fi

log "Using iperf3 server IP: $SERVER_IP"
log "Test duration: ${IPERF_TIME_SEC}s"
TMP_OUT="$(mktemp /tmp/iperf3_client.XXXXXX)"
log "Running: iperf3 -c $SERVER_IP -t $IPERF_TIME_SEC"
echo "---------- iperf3 output begin ----------"
if ! run_live_with_log "$TMP_OUT" iperf3 -c "$SERVER_IP" -t "$IPERF_TIME_SEC"; then
    echo "---------- iperf3 output end   ----------"
    echo "Log file: $TMP_OUT"
    fail "iperf3 client exited with error (see output above)"
fi
echo "---------- iperf3 output end   ----------"
if ! grep -q "receiver" "$TMP_OUT"; then
    rm -f "$TMP_OUT"
    fail "Did not find 'receiver' summary line in iperf3 output – treating as failure"
fi
rm -f "$TMP_OUT"
log "iperf3 CLIENT test PASSED (see above for measured bandwidth)"
exit 0