#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then exec sudo -E "$0" "$@"; fi
  echo "ERROR: must run as root (or install sudo)." >&2
  exit 1
fi

# ------------------------ overrides (env) -------------------------------------
: "${NET_IFACE:=eth0}"
: "${LOCAL_IP:=192.168.2.2}"
: "${PEER_IP:=192.168.2.1}"
: "${LOCAL_MAC:=00:df:00:33:56:01}"
: "${PTP_LOG:=ptp_s.log}"

# Barrier config
: "${CONTROL_PORT:=9900}"
: "${BARRIER_TIMEOUT:=180}"   # seconds

need_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1" >&2; exit 1; }; }
need_cmd ip
need_cmd tc
need_cmd ethtool
need_cmd ptp4l
need_cmd iperf3
need_cmd python3

cleanup() {
  set +e
  pkill -x iperf3 2>/dev/null
  pkill -x ptp4l  2>/dev/null
  tc qdisc del dev "$NET_IFACE" root 2>/dev/null
  tc qdisc del dev "$NET_IFACE" clsact 2>/dev/null
}
trap cleanup EXIT

barrier_listen_once() {
  local name="$1"
  echo "[BARRIER] $name: waiting for devkit1 on port $CONTROL_PORT (timeout ${BARRIER_TIMEOUT}s)..."
  python3 - <<PY
import socket, time, sys
name = ${name!r}
port = int(${CONTROL_PORT})
timeout = int(${BARRIER_TIMEOUT})
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", port))
s.listen(1)
s.settimeout(timeout)
try:
    conn, addr = s.accept()
except Exception as e:
    print(f"[BARRIER] {name}: TIMEOUT waiting for devkit1", file=sys.stderr)
    sys.exit(1)
conn.settimeout(3)
try:
    data = conn.recv(256)
    # optional: print(data.decode(errors="ignore").strip())
    conn.sendall(b"OK\n")
except Exception:
    pass
conn.close()
s.close()
print(f"[BARRIER] {name}: released by devkit1")
PY
}

echo -e "\n---------------- Qbu test (devkit2/server) ----------------------"

# ------------------------ link + addressing ----------------------------------
ip link set dev "$NET_IFACE" down
ip link set dev "$NET_IFACE" address "$LOCAL_MAC"
ip link set dev "$NET_IFACE" up

ip addr flush dev "$NET_IFACE" || true
ip addr add "${LOCAL_IP}/24" dev "$NET_IFACE"

# ------------------------ PTP prioritization ---------------------------------
tc qdisc replace dev "$NET_IFACE" clsact
tc filter add dev "$NET_IFACE" egress prio 1 u32 \
  match ip dport 319 0xffff match ip protocol 17 0xff action skbedit priority 1
tc filter add dev "$NET_IFACE" egress prio 1 u32 \
  match ip dport 320 0xffff match ip protocol 17 0xff action skbedit priority 1

# ------------------------ start PTP (slave) ----------------------------------
ptp4l -i "$NET_IFACE" -m -s > "$PTP_LOG" &
sleep 20
barrier_listen_once "PTP_READY"

# ------------------------ mac-merge toggles ----------------------------------
ethtool --show-mm "$NET_IFACE" || true
ethtool -I --show-mm "$NET_IFACE" || true
sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled on  pmac-enabled on tx-min-frag-size 60
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled on  pmac-enabled on tx-min-frag-size 64
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled off pmac-enabled on tx-min-frag-size 60
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled off pmac-enabled on tx-min-frag-size 60
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled on verify-time 128 tx-enabled on  pmac-enabled on tx-min-frag-size 60
sleep 3
ethtool --show-mm "$NET_IFACE"

barrier_listen_once "MM_READY"

# ------------------------ taprio (WITH hold state) ---------------------------
tc qdisc del dev "$NET_IFACE" root 2>/dev/null || true
tc qdisc add dev "$NET_IFACE" parent root handle 100 taprio \
  num_tc 8 map 0 1 2 3 4 5 6 7 7 7 7 7 7 7 7 7 \
  queues 1@0 1@1 1@2 1@3 1@4 1@5 1@6 1@7 \
  base-time 0 \
  sched-entry R 03 20000 sched-entry R 05 20000 \
  sched-entry R 19 50000 sched-entry R 21 50000 \
  sched-entry H 43 50000 sched-entry H 83 50000 \
  flags 0x2 txtime-delay 0 fp P E E E P E E E

sleep 2
tc qdisc show dev "$NET_IFACE" root
barrier_listen_once "TAPRIO_HOLD_READY"

# ------------------------ PHASE 1 iperf3 server + barrier --------------------
iperf3 -s -1 -B "$LOCAL_IP" &
IPERF_PID=$!
sleep 1
barrier_listen_once "IPERF1_READY"

# Wait for phase1 traffic to finish (server exits after 1 run)
wait "$IPERF_PID" || true
barrier_listen_once "PHASE1_DONE"

# ------------------------ taprio (WITHOUT hold state) -------------------------
echo -e "\n---------------- Qbu test WITHOUT hold state ----------------------"

tc qdisc del dev "$NET_IFACE" root 2>/dev/null || true
tc qdisc add dev "$NET_IFACE" parent root handle 100 taprio num_tc 8 \
  map 0 1 2 3 4 5 6 7 7 7 7 7 7 7 7 7 \
  queues 1@0 1@1 1@2 1@3 1@4 1@5 1@6 1@7 \
  base-time 0 \
  sched-entry S 03 50000 sched-entry S 05 50000 sched-entry S 09 50000 \
  sched-entry S 11 50000 sched-entry S 21 50000 sched-entry S 43 50000 sched-entry S 83 50000 \
  flags 0x2 txtime-delay 0

sleep 2
tc qdisc show dev "$NET_IFACE" root
barrier_listen_once "TAPRIO_NOHOLD_READY"

# ------------------------ PHASE 2 iperf3 server + barrier --------------------
iperf3 -s -1 -B "$LOCAL_IP" &
IPERF2_PID=$!
sleep 1
barrier_listen_once "IPERF2_READY"

wait "$IPERF2_PID" || true
barrier_listen_once "PHASE2_DONE"

ethtool -I --show-mm "$NET_IFACE" || true
echo "[DONE] devkit2/server Qbu test finished."