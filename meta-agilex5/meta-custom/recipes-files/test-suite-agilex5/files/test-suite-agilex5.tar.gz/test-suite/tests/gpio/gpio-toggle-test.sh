#!/usr/bin/env bash
# GPIO toggle test – shell port of gpio/linux/gpio_toggle/test_steps.pl
set -euo pipefail

if [ "${1:-}" = "--desc" ]; then
  echo "Toggle GPIO pin and verify the readback."
  exit 0
fi

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  cat <<'EOF'
Usage:
  test_steps.sh [gpio-pin]

Examples:
  test_steps.sh
  test_steps.sh 512
EOF
  exit 0
fi

# -------------------------------------------------------------------
# Configuration (override with env vars or CLI)
# -------------------------------------------------------------------
# Priority for pin selection:
#   1) CLI arg: ./test-suite run gpio gpio-toggle-test <gpio-pin>
#   2) GPIO_PIN env var
#   3) Default: 512 (to match original test)
GPIO_PIN="${1:-${GPIO_PIN:-512}}"

SYSFS_GPIO_DIR="/sys/class/gpio"
GPIO_CHIP_DIR="${SYSFS_GPIO_DIR}/gpiochip${GPIO_PIN}"
GPIO_PIN_DIR="${SYSFS_GPIO_DIR}/gpio${GPIO_PIN}"

log()  { echo "[gpio-toggle] $*"; }
fail() { echo "[gpio-toggle] FAIL: $*" >&2; exit 1; }

# -------------------------------------------------------------------
# 1. Check that /sys/class/gpio exists and controller is present
# -------------------------------------------------------------------
if [ ! -d "$SYSFS_GPIO_DIR" ]; then
    fail "GPIO sysfs directory not found at $SYSFS_GPIO_DIR (is GPIO enabled in kernel?)"
fi

log "Listing $SYSFS_GPIO_DIR:"
ls "$SYSFS_GPIO_DIR"

if [ ! -d "$GPIO_CHIP_DIR" ]; then
    log "Warning: expected controller directory $GPIO_CHIP_DIR not found"
fi

# -------------------------------------------------------------------
# 2. Export the pin
# -------------------------------------------------------------------
log "Exporting GPIO pin $GPIO_PIN"
if [ -d "$GPIO_PIN_DIR" ]; then
    log "GPIO $GPIO_PIN already exported, unexporting first"
    echo "$GPIO_PIN" > "${SYSFS_GPIO_DIR}/unexport" || fail "Failed to unexport pre-existing GPIO$GPIO_PIN"
fi

echo "$GPIO_PIN" > "${SYSFS_GPIO_DIR}/export" || fail "Failed to export GPIO$GPIO_PIN"

if [ ! -d "$GPIO_PIN_DIR" ]; then
    sleep 0.1
fi

if [ ! -d "$GPIO_PIN_DIR" ]; then
    fail "GPIO pin directory $GPIO_PIN_DIR not found after export"
fi

log "GPIO pin directory exists: $GPIO_PIN_DIR"

# -------------------------------------------------------------------
# 3. Read current direction, then set to 'out'
# -------------------------------------------------------------------
DIR_FILE="${GPIO_PIN_DIR}/direction"
VAL_FILE="${GPIO_PIN_DIR}/value"

if [ ! -f "$DIR_FILE" ]; then
    fail "Direction file not found: $DIR_FILE"
fi
if [ ! -f "$VAL_FILE" ]; then
    fail "Value file not found: $VAL_FILE"
fi

CUR_DIR="$(cat "$DIR_FILE")"
log "Current direction of GPIO$GPIO_PIN: '$CUR_DIR'"

log "Setting direction of GPIO$GPIO_PIN to 'out'"
echo "out" > "$DIR_FILE" || fail "Failed to set direction to 'out'"

NEW_DIR="$(cat "$DIR_FILE")"
log "New direction of GPIO$GPIO_PIN: '$NEW_DIR'"

if [ "$NEW_DIR" != "out" ]; then
    fail "Direction readback mismatch: expected 'out', got '$NEW_DIR'"
fi

# -------------------------------------------------------------------
# 4. Toggle value: 0 then 1, verifying each
# -------------------------------------------------------------------
log "Writing 0 to GPIO$GPIO_PIN"
echo "0" > "$VAL_FILE" || fail "Failed to write 0 to value file"
VAL0="$(cat "$VAL_FILE")"
log "Readback after 0: $VAL0"
if [ "$VAL0" != "0" ]; then
    fail "Value readback mismatch after writing 0 (got '$VAL0')"
fi

log "Writing 1 to GPIO$GPIO_PIN"
echo "1" > "$VAL_FILE" || fail "Failed to write 1 to value file"
VAL1="$(cat "$VAL_FILE")"
log "Readback after 1: $VAL1"
if [ "$VAL1" != "1" ]; then
    fail "Value readback mismatch after writing 1 (got '$VAL1')"
fi

# -------------------------------------------------------------------
# 5. Unexport the pin and confirm removal
# -------------------------------------------------------------------
log "Unexporting GPIO$GPIO_PIN"
echo "$GPIO_PIN" > "${SYSFS_GPIO_DIR}/unexport" || fail "Failed to unexport GPIO$GPIO_PIN"

sleep 0.1

if [ -d "$GPIO_PIN_DIR" ]; then
    fail "GPIO pin directory $GPIO_PIN_DIR still exists after unexport"
fi

log "GPIO toggle test PASSED for pin $GPIO_PIN"
exit 0