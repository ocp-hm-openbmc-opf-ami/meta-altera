#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then exec sudo -E "$0" "$@"; fi
  echo "ERROR: must run as root (or install sudo)." >&2
  exit 1
fi

# ------------------------ overrides (env) -------------------------------------
: "${NET_IFACE:=eth0}"
: "${LOCAL_IP:=192.168.2.1}"
: "${PEER_IP:=192.168.2.2}"
: "${LOCAL_MAC:=00:df:00:33:56:00}"
: "${PTP_LOG:=ptp_m.log}"

: "${TXUDP_BIN:=./tx-udp-0}"
: "${IPERF_TIME_SEC:=10}"

# Barrier config (must match devkit2)
: "${CONTROL_PORT:=9900}"
: "${BARRIER_TIMEOUT:=180}"   # seconds

need_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1" >&2; exit 1; }; }
need_cmd ip
need_cmd tc
need_cmd ethtool
need_cmd ptp4l
need_cmd iperf3

cleanup() {
  set +e
  pkill -x iperf3 2>/dev/null
  pkill -x ptp4l  2>/dev/null
  tc qdisc del dev "$NET_IFACE" root 2>/dev/null
  tc qdisc del dev "$NET_IFACE" clsact 2>/dev/null
}
trap cleanup EXIT

wait_for_ping() {
  local host="$1" timeout="${2:-60}"
  local start
  start=$(date +%s)
  echo "Waiting for ping to $host (timeout ${timeout}s)..."
  while true; do
    if ping -c 1 -W 1 "$host" >/dev/null 2>&1; then
      echo "OK: ping $host"
      return 0
    fi
    if (( $(date +%s) - start >= timeout )); then
      echo "ERROR: timeout waiting ping $host" >&2
      return 1
    fi
    sleep 1
  done
}

barrier_connect() {
  local name="$1"
  local start ts
  start=$(date +%s)
  echo "[BARRIER] $name: waiting to reach devkit2 ($PEER_IP:$CONTROL_PORT) timeout ${BARRIER_TIMEOUT}s..."

  while true; do
    if exec 3<>"/dev/tcp/$PEER_IP/$CONTROL_PORT" 2>/dev/null; then
      echo "$name" >&3
      # read ack if any
      read -r -t 2 _ack <&3 || true
      exec 3<&-; exec 3>&-
      echo "[BARRIER] $name: released (devkit2 was waiting)."
      return 0
    fi
    ts=$(date +%s)
    if (( ts - start >= BARRIER_TIMEOUT )); then
      echo "ERROR: timeout waiting barrier $name" >&2
      return 1
    fi
    sleep 1
  done
}

echo -e "\n---------------- Qbu test (devkit1/client) ----------------------"

# ------------------------ link + addressing ----------------------------------
ip link set dev "$NET_IFACE" down
ip link set dev "$NET_IFACE" address "$LOCAL_MAC"
ip link set dev "$NET_IFACE" up

ip addr flush dev "$NET_IFACE" || true
ip addr add "${LOCAL_IP}/24" dev "$NET_IFACE"

# Make sure peer is reachable before we start barriers
wait_for_ping "$PEER_IP" 60

# ------------------------ PTP prioritization ---------------------------------
tc qdisc replace dev "$NET_IFACE" clsact
tc filter add dev "$NET_IFACE" egress prio 1 u32 \
  match ip dport 319 0xffff match ip protocol 17 0xff action skbedit priority 1
tc filter add dev "$NET_IFACE" egress prio 1 u32 \
  match ip dport 320 0xffff match ip protocol 17 0xff action skbedit priority 1

# ------------------------ start PTP ------------------------------------------
ptp4l -i "$NET_IFACE" -m > "$PTP_LOG" &
sleep 20
barrier_connect "PTP_READY"

# ------------------------ mac-merge toggles ----------------------------------
tc qdisc del dev "$NET_IFACE" root 2>/dev/null || true

ethtool --show-mm "$NET_IFACE" || true
ethtool -I --show-mm "$NET_IFACE" || true
sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled on  pmac-enabled on tx-min-frag-size 60
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled on  pmac-enabled on tx-min-frag-size 64
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled off pmac-enabled on tx-min-frag-size 60
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled off verify-time 128 tx-enabled off pmac-enabled on tx-min-frag-size 60
ethtool --show-mm "$NET_IFACE"; sleep 2

ethtool --set-mm "$NET_IFACE" verify-enabled on verify-time 128 tx-enabled on  pmac-enabled on tx-min-frag-size 60
sleep 3
ethtool --show-mm "$NET_IFACE"

barrier_connect "MM_READY"

# ------------------------ taprio (WITH hold state) ---------------------------
tc qdisc del dev "$NET_IFACE" root 2>/dev/null || true
tc qdisc add dev "$NET_IFACE" parent root handle 100 taprio \
  num_tc 8 map 0 1 2 3 4 5 6 7 7 7 7 7 7 7 7 7 \
  queues 1@0 1@1 1@2 1@3 1@4 1@5 1@6 1@7 \
  base-time 0 \
  sched-entry R 03 20000 sched-entry R 05 20000 \
  sched-entry R 19 50000 sched-entry R 21 50000 \
  sched-entry H 43 50000 sched-entry H 83 50000 \
  flags 0x2 txtime-delay 0 fp P E E E P E E E

sleep 2
tc qdisc show dev "$NET_IFACE" root
barrier_connect "TAPRIO_HOLD_READY"

# ------------------------ PHASE 1 traffic (wait for server barrier) ----------
barrier_connect "IPERF1_READY"

# iperf3 client + tx-udp-0
iperf3 -c "$PEER_IP" -t "$IPERF_TIME_SEC" &
sleep 1

if [[ -x "$TXUDP_BIN" ]]; then
  "$TXUDP_BIN" -i "$NET_IFACE" -d "$PEER_IP" -t 500000 -n 100000 -q 8 &
else
  echo "WARN: TXUDP_BIN not found/executable: $TXUDP_BIN (skipping tx-udp-0)" >&2
fi

sleep $((IPERF_TIME_SEC + 3))
pkill -x iperf3 2>/dev/null || true
ethtool -I --show-mm "$NET_IFACE" || true

# Tell devkit2 phase1 done
barrier_connect "PHASE1_DONE"

# ------------------------ taprio (WITHOUT hold state) -------------------------
echo -e "\n---------------- Qbu test WITHOUT hold state ----------------------"

tc qdisc del dev "$NET_IFACE" root 2>/dev/null || true
tc qdisc add dev "$NET_IFACE" parent root handle 100 taprio num_tc 8 \
  map 0 1 2 3 4 5 6 7 7 7 7 7 7 7 7 7 \
  queues 1@0 1@1 1@2 1@3 1@4 1@5 1@6 1@7 \
  base-time 0 \
  sched-entry S 03 50000 sched-entry S 05 50000 sched-entry S 09 50000 \
  sched-entry S 11 50000 sched-entry S 21 50000 sched-entry S 43 50000 sched-entry S 83 50000 \
  flags 0x2 txtime-delay 0

sleep 2
tc qdisc show dev "$NET_IFACE" root
barrier_connect "TAPRIO_NOHOLD_READY"

# ------------------------ PHASE 2 traffic (wait for server barrier) ----------
barrier_connect "IPERF2_READY"

if [[ -x "$TXUDP_BIN" ]]; then
  "$TXUDP_BIN" -i "$NET_IFACE" -d "$PEER_IP" -t 0 -n 10 -q 8 &
fi

iperf3 -c "$PEER_IP" -t "$IPERF_TIME_SEC" &
sleep $((IPERF_TIME_SEC + 2))
pkill -x iperf3 2>/dev/null || true

# Tell devkit2 phase2 done
barrier_connect "PHASE2_DONE"

echo "[DONE] devkit1/client Qbu test finished."